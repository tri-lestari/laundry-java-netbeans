<?php 
	$con = mysqli_connect("localhost", "root", "", "laundry_pro");
 ?>